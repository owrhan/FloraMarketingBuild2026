Flora Marketing — مشروع Android جاهز للبناء عبر GitHub Actions

مهم: هذا ملف المشروع المصدر، وليس ملف APK جاهزاً للتثبيت. سيتم بناء APK على GitHub.

الطريقة الأسهل من هاتف Android:
1) افتح المستودع: https://github.com/owrhan/FloraMarketingBuild
2) افتح تبويب Code ثم اضغط Add file > Upload files.
3) ارفع ملف FloraMarketing-Android-Project-Final.zip إلى جذر المستودع (لا تفك ضغطه).
4) اضغط Commit changes.
5) افتح مجلد .github/workflows في المستودع. يجب أن يكون ملف build-apk.yml موجوداً في هذا المسار في جذر المستودع، وليس داخل ملف ZIP فقط.
6) إذا لم يكن موجوداً، أنشئ الملف من Add file > Create new file واكتب المسار كاملاً: .github/workflows/build-apk.yml
7) الصق محتوى ملف build-apk.yml المرفق بشكل منفصل مع حزمة المشروع (إن لم يكن موجوداً مسبقاً)، ثم Commit changes.
8) افتح Actions > Build Flora Marketing APK > Run workflow > Run workflow.
9) انتظر حتى تنتهي المهمة بعلامة خضراء، ثم افتح نتيجة التشغيل وانزل إلى Artifacts.
10) اضغط FloraMarketing-debug-apk لتنزيل ملف ZIP يحتوي على APK. فك ضغطه على الهاتف ثم ثبّت app-debug.apk.

ملاحظات:
- لا ترفع مجلد app/build أو APK يدوياً؛ GitHub يبني التطبيق من المصدر.
- احتفظ بنسخة احتياطية من بيانات التطبيق قبل تثبيت أي نسخة جديدة.
- قد لا يقبل Android تثبيت النسخة الجديدة فوق نسخة سابقة إذا اختلف توقيع APK؛ لا تحذف النسخة القديمة قبل التأكد من وجود نسخة احتياطية من بياناتك.
- يجب اختبار التصدير والطباعة ونسخ البيانات احتياطياً على الهاتف بعد التثبيت.
- زر «زيارة جديدة» أصبح زر + أخضر بارزاً في منتصف الشريط السفلي.
