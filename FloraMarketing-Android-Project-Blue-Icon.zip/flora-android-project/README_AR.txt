مشروع Android لتغليف تطبيق Flora HTML داخل تطبيق Android WebView.

لإنشاء APK:
1) ثبّت Android Studio على كمبيوتر Windows أو Mac أو Linux.
2) فك ضغط مجلد FloraMarketing-Android-Project.zip.
3) من Android Studio اختر Open ثم افتح مجلد flora-android-project.
4) وافق على تنزيل مكونات Gradle وAndroid SDK المطلوبة عند الطلب.
5) من القائمة اختر Build > Build Bundle(s) / APK(s) > Build APK(s).
6) بعد اكتمال البناء سيظهر إشعار؛ اضغط locate للعثور على APK.

مهم:
- هذا المشروع لا يحتوي APK مبنيًا مسبقًا؛ يلزم Android Studio/Android SDK لبنائه.
- اسم الحزمة الحالي com.flora.marketing. إذا كان لديك APK قديم، فقد لا يمكن تثبيت هذا فوقه كتحديث إذا كانت هوية الحزمة أو شهادة التوقيع مختلفة.
- احتفظ بنسخة احتياطية من بيانات التطبيق قبل تجربة أي APK جديد.
- الصور والملفات والنسخ الاحتياطي تحتاج اختبارًا على هاتف Android بعد البناء؛ طريقة اختيار الملفات مهيأة عبر WebView، لكن سلوك الكاميرا والطباعة/تصدير PDF قد يختلف حسب إصدار Android.
